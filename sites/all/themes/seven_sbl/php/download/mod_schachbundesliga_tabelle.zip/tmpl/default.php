<?php
defined('_JEXEC') or die;
$document = JFactory::getDocument();
JHTML::_('stylesheet', JUri::root() . 'modules/mod_schachbundesliga_tabelle/assets/css/custom.css');
$text = "<script type=\"text/javascript\" src=\"https://www.schachbundesliga.de/sites/all/themes/seven_sbl/php/sbl_blitztabelle.php\"></script>";
$text=JHtml::_('content.prepare', $text);
echo $text;
?>