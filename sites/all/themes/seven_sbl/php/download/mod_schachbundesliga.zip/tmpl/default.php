<?php
defined('_JEXEC') or die;
$document = JFactory::getDocument();
JHTML::_('script', JUri::root() . 'modules/mod_schachbundesliga/assets/js/jquery.bootstrap.newsbox.min.js');
JHTML::_('stylesheet', JUri::root() . 'modules/mod_schachbundesliga/assets/css/custom.css');
JHTML::_('stylesheet', JUri::root() . 'modules/mod_schachbundesliga/assets/css/bootstrap.min.css');
JHTML::_('stylesheet', JUri::root() . 'modules/mod_schachbundesliga/assets/css/bootstrap-theme.min.css');

$headlinecolor=str_replace("#","",$params->get('headlinecolor'));
$backgroundcolor=str_replace("#","",$params->get('backgroundcolor'));

$text = "<script type=\"text/javascript\" src=\"http://www.schachbundesliga.de/sites/all/themes/seven_sbl/php/sbl_newsticker.php?design=".$params->get('design')."&anzahl_beitraege=".$params->get('anzahl_beitraege')."&headlinecolor=".$headlinecolor."&backgroundcolor=".$backgroundcolor."\"></script>";
$text=JHtml::_('content.prepare', $text);
echo $text;
?>