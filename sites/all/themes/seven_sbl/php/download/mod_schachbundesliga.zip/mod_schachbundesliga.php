<?php
/**
 * @copyright	Copyright © 2016 - All rights reserved.
 * @license		GNU General Public License v2.0
 * @generator	http://xdsoft/joomla-module-generator/
 */
defined('_JEXEC') or die;

$doc = JFactory::getDocument();
/* Available fields:"anzahl_beitraege","desgin", */
// Include assets
$doc->addStyleSheet(JURI::root()."modules/mod_schachbundesliga/assets/css/style.css");
$doc->addScript(JURI::root()."modules/mod_schachbundesliga/assets/js/script.js");
// $width 			= $params->get("width");

/**
	$db = JFactory::getDBO();
	$db->setQuery("SELECT * FROM #__mod_schachbundesliga where del=0 and module_id=".$module->id);
	$objects = $db->loadAssocList();
*/
require JModuleHelper::getLayoutPath('mod_schachbundesliga', $params->get('layout', 'default'));